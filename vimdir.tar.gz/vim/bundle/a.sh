git clone https://github.com/vim-airline/vim-airline.git
